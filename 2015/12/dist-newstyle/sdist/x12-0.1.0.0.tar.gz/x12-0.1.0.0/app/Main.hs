module Main where
import Data.Aeson

main :: IO ()
main = putStrLn "Hello, Haskell!"

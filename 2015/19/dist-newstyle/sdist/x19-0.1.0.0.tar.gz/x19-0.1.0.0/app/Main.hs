module Main where
import Data.Map (Map, empty, insertWith, member, lookup, insert, keys, (!), toList)
import Data.List.Split (splitOn)
import Data.List (isPrefixOf, find, sort, sortOn, isInfixOf)
import Data.Set (Set, empty, union, fromList, null, toList, member, map, filter, take)
import Data.Char (isUpper)
import Data.Maybe (isNothing, fromJust)
import qualified Data.Text as T

type Instructions = Map String (Set String)
type Possibilites = Set String

main :: IO ()
main = do
    input <- readFile "test.txt"
    let [m,w]= splitOn "\n\n" input
    let (instructions, instructions') = foldl parseMap (Data.Map.empty, Data.Map.empty) $ Prelude.map words $ lines m
    -- print instructions'
    -- let exp = iterate (getNextPossibility' instructions' []) w !! 15
    -- let exp = iterate (extendTarget instructions' "e") (fromList [w]) !! 50
    -- print (length exp, Data.Set.member "e" exp)
    print (length $ getPossibilities instructions w [], reduce (Prelude.map (\(a,b) -> (a, Data.Set.toList b))(Data.Map.toList instructions')) w)

parseMap :: (Instructions, Instructions) -> [String] -> (Instructions, Instructions)
parseMap (m,m') [from, "=>", to] = (insertWith Data.Set.union from (fromList [to]) m, insertWith Data.Set.union to (fromList [from]) m')

findReduce :: [(String, [String])] -> String -> String -> String
findReduce instructions target from = case reduce instructions from of
    t | t == target -> t
    t -> findReduce instructions target t

reduce :: [(String, [String])] -> String -> String
reduce [] s = s
reduce ((from, [to]):xs) s 
    | from `isInfixOf` s = reduce ((from, [to]):xs) (replaceSubstring from to s)
    | otherwise = reduce xs s

-- searchSequence :: Instructions -> String -> [String] -> (String, Bool)
-- searchSequence instructions target (x:xs)
--     | target `elem` (x:xs) = (target, True)
--     | otherwise = 
--         let possibilities' = getPossibilities instructions x []
--             (t, res) = searchSequence instructions target [head $ toList possibilities'] in
--         (t, res)
        -- if res || Data.Set.null possibilities' then (t, res) else searchSequence instructions target xs

-- searchSequence :: Instructions -> String -> Possibilites -> Int -> Int
-- searchSequence instructions target currentConstructions c = if Data.Set.member target currentConstructions then c else
--     let possibilites = foldl (\acc x -> acc `union` Data.Set.filter (\y -> length y <= length x) (getPossibilities instructions x [])) Data.Set.empty currentConstructions
--     in 1 + searchSequence instructions target (Data.Set.filter (\p -> notElem 'e' p || length p == 1) possibilites) c

extendTarget :: Instructions -> String -> Possibilites -> Possibilites
extendTarget instructions target pos = if Data.Set.member target pos then pos else
    foldl (\acc x -> acc `union` getPossibilities instructions x []) Data.Set.empty (Data.Set.take 2000 pos)

getPossibilities :: Instructions -> String -> String -> Possibilites
getPossibilities instructions [] prev = Data.Set.empty
getPossibilities instructions xs prev =
    let coincidence = Prelude.filter (`isPrefixOf` xs) (keys instructions)
    in if Prelude.null coincidence then getPossibilities instructions (tail xs) (prev ++ [head xs]) else
        foldl (\acc x -> acc `union` getPossibilitiesForKey instructions xs x prev) Data.Set.empty coincidence

getNextPossibility' :: Instructions -> String -> String -> String
getNextPossibility' instructions prev [] = prev
getNextPossibility' instructions prev xs =
    let coincidence = find (`isPrefixOf` xs) (keys instructions)
    in if isNothing coincidence then getNextPossibility' instructions (prev ++ [head xs]) (tail xs) else
        getNextPossibility' instructions (prev ++ head (Data.Set.toList (instructions ! fromJust coincidence))) (drop (length $ fromJust coincidence) xs)
    -- in (fromJust coincidence, 0)

getPossibilitiesForKey :: Instructions -> String -> String -> String -> Possibilites
getPossibilitiesForKey instructions xs key prev = Data.Set.map (prev++) (getReplacements instructions key (drop (length key) xs))
    `union` getPossibilities instructions (drop (length key) xs) (prev ++ key)

getReplacements :: Instructions -> String -> String -> Possibilites
getReplacements intructions key t = case Data.Map.lookup key intructions of
    Just x -> Data.Set.map (++ t) x
    Nothing -> Data.Set.empty

replaceSubstring :: String -> String -> String -> String
replaceSubstring old new = T.unpack . T.replace (T.pack old) (T.pack new) . T.pack